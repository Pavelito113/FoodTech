console.log("📘 EditManufacturer.js загружен");

window.initEditManufacturer = function (container) {
    console.log("🛠 Инициализация EditManufacturer");

    const form = container.querySelector("#manufacturerForm");
    if (!form) {
        console.warn("❌ Форма производителя не найдена");
        return;
    }

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const btn = form.querySelector("button[type='submit']");
        btn.disabled = true;
        btn.innerHTML = "⌛ Сохранение...";

        try {
            const res = await fetch("/Admin/EditManufacturer", {
                method: "POST",
                body: formData,
                headers: { "Accept": "application/json" }
            });

            const result = await res.json();

            if (result.success) {
                window.showToast("Данные завода сохранены", "success");
            } else {
                window.showToast(result.message || "Ошибка при сохранении", "danger");
            }
        } catch (err) {
            window.showToast("Ошибка: " + err.message, "danger");
        } finally {
            btn.disabled = false;
            btn.innerHTML = "💾 Сохранить";
        }
    });

    console.log("✅ EditManufacturer инициализирован");
};

// === РЕГИСТРАЦИЯ В PartialManager ===
if (typeof window.PartialManager !== "undefined") {
    window.PartialManager.register("EditManufacturer", window.initEditManufacturer);
    console.log("🎯 EditManufacturer зарегистрирован в PartialManager");
} else {
    const checkPM = setInterval(() => {
        if (typeof window.PartialManager !== "undefined") {
            clearInterval(checkPM);
            window.PartialManager.register("EditManufacturer", window.initEditManufacturer);
            console.log("✅ EditManufacturer зарегистрирован (отложенно)");
        }
    }, 100);
}

console.log("🏁 EditManufacturer.js завершен");
