// 📘 EditRequests.js — полностью синхронизирован с RequestsController

console.log("📘 EditRequests.js загружен (актуальная версия)");

(function () {
    if (!window.PartialManager) {
        console.error("❌ PartialManager не найден!");
        return;
    }

    PartialManager.register("RequestManagement", async (container) => {
        console.log("🔧 Инициализация RequestManagement...");

        const rows = container.querySelectorAll("[data-row]");
        const modal = container.querySelector("#requestModal");
        const form = container.querySelector("#requestForm");

        if (!modal || !form) {
            console.warn("⚠ Не найдена модалка или форма");
            return;
        }

        let bootstrapModal = new bootstrap.Modal(modal);

        rows.forEach(row => {
            row.addEventListener("click", async () => {
                const id = row.dataset.id;
                if (!id) return;

                try {
                    const response = await fetch(`/Admin/GetRequest?id=${id}`, {
                        headers: { "X-Requested-With": "XMLHttpRequest" }
                    });

                    if (!response.ok) throw new Error("Ошибка загрузки данных");

                    const data = await response.json();

                    form.querySelector("[name='ContactRequestId']").value = data.contactRequestId ?? "";
                    form.querySelector("[name='EquipmentId']").value = data.equipmentId ?? "";
                    form.querySelector("[name='EquipmentName']").value = data.equipmentName ?? "";
                    form.querySelector("[name='Name']").value = data.name ?? "";
                    form.querySelector("[name='Email']").value = data.email ?? "";
                    form.querySelector("[name='Phone']").value = data.phone ?? "";
                    form.querySelector("[name='Company']").value = data.company ?? "";
                    form.querySelector("[name='Message']").value = data.message ?? "";
                    form.querySelector("[name='SourceUrl']").value = data.sourceUrl ?? "";
                    form.querySelector("[name='Status']").value = data.status ?? "";

                    bootstrapModal.show();

                } catch (err) {
                    console.error(err);
                    showToast("Ошибка загрузки запроса", "danger");
                }
            });
        });

        // ✔ Сохранение
        form.addEventListener("submit", async (e) => {
            e.preventDefault();

            const formData = new FormData(form);

            try {
                const response = await fetch("/Admin/SaveRequest", {
                    method: "POST",
                    body: formData,
                });

                if (!response.ok) throw new Error("Ошибка сохранения");

                bootstrapModal.hide();
                showToast("Изменения сохранены");

                // Перезагружаем вкладку
                loadTab("/Admin?tab=RequestManagement", "adminContent", "RequestManagement");

            } catch (err) {
                console.error(err);
                showToast("Ошибка при сохранении", "danger");
            }
        });
    });
})();
