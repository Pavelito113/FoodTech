// 📘 EditUsers.js — логика вкладки "Пользователи"
console.log("📘 EditUsers.js загружен");

if (!window.PartialManager) {
    console.error("❌ PartialManager не найден!");
} else {
    PartialManager.register("EditUsers", initEditUsers);
}

// ====================================================================
// 🚀 ОСНОВНАЯ ИНИЦИАЛИЗАЦИЯ ВКЛАДКИ
// ====================================================================
function initEditUsers(container) {
    console.log("🚀 Инициализация EditUsers");

    initAdd(container);
    initEdit(container);
    initRole(container);
    initFreeze(container);
    initDelete(container);

    console.log("✅ EditUsers инициализирован");
}
// ====================================================================
// ➕ ДОБАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯ
// ====================================================================
function initAdd(root) {
    const form = document.querySelector("#addUserForm");
    const modalEl = document.querySelector("#addUserModal");
    const submitBtn = document.querySelector("#addUserSubmitBtn");
    
    if (!form || !modalEl || !submitBtn) {
        console.warn("❌ Элементы добавления пользователя не найдены");
        return;
    }

    console.log("✅ Форма добавления найдена");

    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);

    form.addEventListener("submit", async e => {
        e.preventDefault();
        
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Сохранение...';
        submitBtn.disabled = true;

        try {
            const data = Object.fromEntries(new FormData(form).entries());
            console.log("📤 Отправка данных добавления:", data);

            const res = await fetch("/admin/users/add", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });

            const json = await safeJson(res);
            console.log("📥 Ответ сервера:", json);

            if (!json.success) {
                showToast(json.message, "danger");
                return;
            }

            // Показываем временный пароль
            showPasswordModal(json.tempPassword, data.Email);
            
            showToast("Пользователь создан", "success");
            modal.hide();
            form.reset();

            await reloadEditUsers();
        } catch (err) {
            console.error("❌ Ошибка:", err);
            showToast("Ошибка создания пользователя", "danger");
        } finally {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    });
}

// ====================================================================
// 🔑 МОДАЛКА С ВРЕМЕННЫМ ПАРОЛЕМ
// ====================================================================
function showPasswordModal(tempPassword, email) {
    // Находим элементы модалки
    const emailInput = document.getElementById('tempPasswordEmail');
    const passwordInput = document.getElementById('tempPasswordValue');
    const copyEmailBtn = document.getElementById('copyEmailBtn');
    const copyPasswordBtn = document.getElementById('copyPasswordBtn');
    const tempPasswordModalEl = document.getElementById('tempPasswordModal');
    
    if (!emailInput || !passwordInput || !tempPasswordModalEl) {
        console.error('❌ Элементы модалки временного пароля не найдены');
        return;
    }

    // Заполняем данные
    emailInput.value = email;
    passwordInput.value = tempPassword;

    // Обновляем обработчики копирования
    copyEmailBtn.onclick = () => copyToClipboard('tempPasswordEmail');
    copyPasswordBtn.onclick = () => copyToClipboard('tempPasswordValue');

    // Показываем модалку
    const tempPasswordModal = bootstrap.Modal.getOrCreateInstance(tempPasswordModalEl);
    tempPasswordModal.show();
}

// ====================================================================
// 📋 КОПИРОВАНИЕ В БУФЕР ОБМЕНА
// ====================================================================
function copyToClipboard(elementId) {
    const element = document.getElementById(elementId);
    if (!element) {
        console.error(`❌ Элемент с ID ${elementId} не найден`);
        return;
    }
    
    element.select();
    element.setSelectionRange(0, 99999); // Для мобильных устройств
    
    try {
        navigator.clipboard.writeText(element.value).then(() => {
            showToast("Скопировано в буфер обмена", "success");
        });
    } catch (err) {
        // Fallback для старых браузеров
        document.execCommand('copy');
        showToast("Скопировано в буфер обмена", "success");
    }
}

// ====================================================================
// ✏ РЕДАКТИРОВАНИЕ ПОЛЬЗОВАТЕЛЯ
// ====================================================================
function initEdit(root) {
    const modalEl = document.querySelector("#editUserModal");
    const form = document.querySelector("#editUserForm");
    const submitBtn = document.querySelector("#editUserSubmitBtn");
    
    if (!modalEl || !form || !submitBtn) {
        console.warn("❌ Элементы редактирования пользователя не найдены:", {
            modal: !!modalEl,
            form: !!form,
            submitBtn: !!submitBtn
        });
        return;
    }

    console.log("✅ Форма редактирования найдена");

    const modal = bootstrap.Modal.getOrCreateInstance(modalEl);

    // Инициализация кнопок редактирования - ищем в переданном контейнере
    root.querySelectorAll(".edit-user").forEach(btn => {
        btn.addEventListener("click", () => {
            const tr = btn.closest("tr");
            if (!tr) return;

            const userId = tr.dataset.userId;
            const name = tr.children[0].textContent.trim();
            const email = tr.children[1].textContent.trim();
            const company = tr.children[2].textContent.trim();
            const phone = tr.children[3].textContent.trim();

            console.log(`✏️ Редактирование пользователя: ${name} (${userId})`);

            form.querySelector("[name='Id']").value = userId;
            form.querySelector("[name='Name']").value = name;
            form.querySelector("[name='Email']").value = email;
            form.querySelector("[name='Company']").value = company;
            form.querySelector("[name='Phone']").value = phone;

            modal.show();
        });
    });

    // Обработка отправки формы редактирования
    form.addEventListener("submit", async e => {
        e.preventDefault();
        
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status"></span> Сохранение...';
        submitBtn.disabled = true;

        try {
            const data = Object.fromEntries(new FormData(form).entries());
            console.log("📤 Отправка данных редактирования:", data);

            const res = await fetch("/admin/users/edit", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(data)
            });

            const json = await safeJson(res);
            console.log("📥 Ответ сервера:", json);

            if (!json.success) {
                showToast(json.message, "danger");
                return;
            }

            showToast("Изменения сохранены", "success");
            modal.hide();

            await reloadEditUsers();
        } catch (err) {
            console.error("❌ Ошибка:", err);
            showToast("Ошибка сохранения изменений", "danger");
        } finally {
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }
    });
}

// ====================================================================
// 🎭 ОБНОВЛЕНИЕ РОЛИ
// ====================================================================
function initRole(root) {
    root.querySelectorAll(".user-role").forEach(select => {
        select.addEventListener("change", async () => {
            const userId = select.dataset.id;
            const role = select.value;

            console.log(`🎭 Смена роли пользователя ${userId} на ${role}`);

            try {
                const res = await fetch("/admin/users/update-role", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        userId: userId,
                        role: role
                    })
                });

                const json = await safeJson(res);
                console.log("📥 Ответ обновления роли:", json);

                showToast(json.message, json.success ? "success" : "danger");
            } catch (err) {
                console.error("❌ Ошибка:", err);
                showToast("Ошибка обновления роли", "danger");
            }
        });
    });
}
// ====================================================================
// ❄ FREEZE/UNFREEZE
// ====================================================================
function initFreeze(root) {
    root.querySelectorAll(".freeze-user").forEach(btn => {
        btn.addEventListener("click", async () => {
            const tr = btn.closest("tr");
            const id = tr?.dataset.userId;
            if (!id) return;

            const isCurrentlyFrozen = tr.classList.contains("table-secondary");
            const userName = tr.children[0].textContent.trim();

            if (!confirm(isCurrentlyFrozen 
                ? `Разморозить пользователя "${userName}"?` 
                : `Заморозить пользователя "${userName}"?`)) return;

            try {
                console.log(`❄ ${isCurrentlyFrozen ? 'Разморозка' : 'Заморозка'} пользователя: ${id}`);
                const res = await fetch("/admin/users/freeze", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(id)
                });

                const json = await safeJson(res);
                console.log("📥 Ответ заморозки:", json);

                if (!json.success) {
                    showToast(json.message, "danger");
                    return;
                }

                // Обновляем UI без перезагрузки всей страницы
                updateUserFreezeUI(tr, btn, json.frozen);
                
                showToast(json.frozen ? "Пользователь заморожен" : "Пользователь разморожен", "success");
                
            } catch (err) {
                console.error("❌ Ошибка:", err);
                showToast("Ошибка операции", "danger");
            }
        });
    });
}

// ====================================================================
// 🎨 ОБНОВЛЕНИЕ ВИЗУАЛЬНОГО СТАТУСА ЗАМОРОЗКИ
// ====================================================================
function updateUserFreezeUI(tr, btn, isFrozen) {
    // Обновляем строку таблицы
    if (isFrozen) {
        tr.classList.add("table-secondary", "text-muted");
    } else {
        tr.classList.remove("table-secondary", "text-muted");
    }

    // Обновляем иконку рядом с именем
    const nameCell = tr.children[0];
    let snowIcon = nameCell.querySelector(".bi-snow");
    if (isFrozen && !snowIcon) {
        const icon = document.createElement("i");
        icon.className = "bi bi-snow text-primary me-1";
        icon.title = "Заморожен";
        nameCell.insertBefore(icon, nameCell.firstChild);
    } else if (!isFrozen && snowIcon) {
        snowIcon.remove();
    }

    // Обновляем бейдж статуса
    const statusCell = tr.children[5];
    if (isFrozen) {
        statusCell.innerHTML = '<span class="badge bg-warning text-dark"><i class="bi bi-snow"></i> Заморожен</span>';
    } else {
        statusCell.innerHTML = '<span class="badge bg-success"><i class="bi bi-check-circle"></i> Активен</span>';
    }

    // Обновляем кнопку заморозки
    if (isFrozen) {
        btn.classList.remove("btn-outline-warning");
        btn.classList.add("btn-warning");
        btn.title = "Разморозить";
    } else {
        btn.classList.remove("btn-warning");
        btn.classList.add("btn-outline-warning");
        btn.title = "Заморозить";
    }
}

// ====================================================================
// 🗑 DELETE
// ====================================================================
function initDelete(root) {
    root.querySelectorAll(".delete-user").forEach(btn => {
        btn.addEventListener("click", async () => {
            const id = btn.closest("tr")?.dataset.userId;
            if (!id) return;

            if (!confirm("Удалить пользователя? Это действие нельзя отменить.")) return;

            try {
                console.log(`🗑 Удаление пользователя: ${id}`);
                const res = await fetch("/admin/users/delete", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(id)
                });

                const json = await safeJson(res);
                console.log("📥 Ответ удаления:", json);

                if (json.success) {
                    showToast("Пользователь удалён", "success");
                    await reloadEditUsers();
                } else {
                    showToast(json.message, "danger");
                }
            } catch (err) {
                console.error("❌ Ошибка:", err);
                showToast("Ошибка удаления пользователя", "danger");
            }
        });
    });
}

// ====================================================================
// 🔄 ПЕРЕЗАГРУЗКА
// ====================================================================
async function reloadEditUsers() {
    const wrap = document.querySelector("#editUsersContainer");
    if (!wrap) {
        console.warn("❌ Контейнер пользователей не найден для перезагрузки");
        return;
    }

    try {
        console.log("🔄 Перезагрузка списка пользователей");
        const res = await fetch("/admin/users");
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        
        const html = await res.text();
        wrap.outerHTML = html;

        // Переинициализируем partial
        if (window.PartialManager) {
            setTimeout(() => {
                console.log("🔄 Переинициализация EditUsers после перезагрузки");
                PartialManager.reinit("EditUsers");
            }, 100);
        }
    } catch (err) {
        console.error("❌ Ошибка перезагрузки пользователей:", err);
        showToast("Ошибка обновления списка пользователей", "danger");
    }
}

// ====================================================================
// 🔒 safe JSON (если не определен в site.js)
// ====================================================================
if (typeof safeJson === 'undefined') {
    async function safeJson(res) {
        try { 
            return await res.json(); 
        } catch { 
            return { success: false, message: "Ошибка ответа сервера" }; 
        }
    }
}

if (typeof showToast === 'undefined') {
    function showToast(message, type = "info") {
        // Простая реализация, если нет системы уведомлений
        alert(`[${type.toUpperCase()}] ${message}`);
    }
}