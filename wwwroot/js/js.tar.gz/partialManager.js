(function () {
    if (!window.PartialManager) {
        console.error("PartialManager не найден");
        return;
    }

    console.log("✅ admin-partials.js загружен");

    const tabs = document.querySelectorAll('#adminTabs [data-tab]');
    const content = document.getElementById('tabContent');

    tabs.forEach(tab => {
        tab.addEventListener('click', async () => {
            const name = tab.dataset.tab;
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');

            // 🧩 Определяем маршрут в зависимости от вкладки
            const map = {
                EditUsers: "/admin/users",
                EditManufacturer: "/admin/manufacturers",
                EditCategories: "/admin/categories",     // ✅ Добавлено
                EditIndustries: "/admin/industries",     // ✅ Добавлено
                RequestManagement: "/admin/requests"
            };

            const url = map[name];
            if (!url) {
                console.warn(`⚠️ Для вкладки ${name} не найден маршрут`);
                return;
            }

            try {
                const resp = await fetch(url);
                if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
                const html = await resp.text();
                content.innerHTML = html;

                // ⚙️ передаём имя вкладки
                PartialManager.init(name, content);

                localStorage.setItem("activeTab", name);
                console.log(`✅ Вкладка ${name} загружена`);
            } catch (err) {
                console.error(`❌ Ошибка загрузки вкладки ${name}:`, err);
                content.innerHTML = `<div class="alert alert-danger">Ошибка загрузки вкладки ${name}</div>`;
            }
        });
    });

    // 🔁 Восстановление активной вкладки
    const saved = localStorage.getItem("activeTab");
    const active = saved || "EditUsers";
    document.querySelector(`[data-tab="${active}"]`)?.click();
})();